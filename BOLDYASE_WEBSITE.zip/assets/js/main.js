// JS functionaliteiten voor navbar, formulierverwerking, etc.
console.log('Main JS geladen.');
